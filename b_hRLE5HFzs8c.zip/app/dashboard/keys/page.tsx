"use client"

import { useMemo, useState } from "react"
import {
  Check,
  Copy,
  Key,
  MapPin,
  Phone,
  Plus,
  Search,
  ShieldAlert,
  User,
} from "lucide-react"
import { toast } from "sonner"
import { PageHeader } from "@/components/dashboard/page-header"
import { ConfirmDialog } from "@/components/dashboard/confirm-dialog"
import { KeyCard } from "@/components/dashboard/key-card"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { mockKeys, expireOptions, type ApiKey } from "@/lib/mock-data"
import { cn } from "@/lib/utils"

const emptyForm: Omit<ApiKey, "id" | "deviceCount" | "lastIp" | "lastSeen"> = {
  code: "",
  status: "active",
  expireDate: expireOptions[3],
  maxDevices: 2,
  subscriberName: "",
  phone: "",
  address: "",
  note: "",
}

function copy(text: string) {
  if (typeof navigator !== "undefined" && navigator.clipboard) {
    navigator.clipboard.writeText(text)
    toast.success("تم النسخ")
  }
}

export default function KeysPage() {
  const [keys, setKeys] = useState<ApiKey[]>(mockKeys)
  const [query, setQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")

  const [editing, setEditing] = useState<ApiKey | null>(null)
  const [editForm, setEditForm] = useState<ApiKey | null>(null)

  const [adding, setAdding] = useState(false)
  const [addForm, setAddForm] = useState({ ...emptyForm })

  const [confirmDelete, setConfirmDelete] = useState<ApiKey | null>(null)
  const [confirmReset, setConfirmReset] = useState<ApiKey | null>(null)

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    return keys.filter((k) => {
      const matchesQuery =
        !q ||
        k.code.toLowerCase().includes(q) ||
        k.subscriberName.toLowerCase().includes(q) ||
        k.phone.includes(q) ||
        k.lastIp.includes(q)
      const matchesStatus = statusFilter === "all" || k.status === statusFilter
      return matchesQuery && matchesStatus
    })
  }, [keys, query, statusFilter])

  function openEdit(k: ApiKey) {
    setEditing(k)
    setEditForm({ ...k })
  }

  function saveEdit() {
    if (!editForm) return
    if (!editForm.subscriberName.trim()) {
      toast.error("اسم المشترك مطلوب")
      return
    }
    setKeys((prev) => prev.map((k) => (k.id === editForm.id ? editForm : k)))
    toast.success("تم حفظ تعديلات المفتاح")
    setEditing(null)
    setEditForm(null)
  }

  function addKey() {
    if (!addForm.code.trim()) {
      toast.error("أدخل كود التفعيل")
      return
    }
    if (!addForm.subscriberName.trim()) {
      toast.error("أدخل اسم المشترك")
      return
    }
    const id = Math.max(0, ...keys.map((k) => k.id)) + 1
    setKeys((prev) => [
      {
        id,
        code: addForm.code.trim().toUpperCase(),
        status: addForm.status,
        expireDate: addForm.expireDate,
        deviceCount: 0,
        maxDevices: Number(addForm.maxDevices) || 1,
        lastIp: "—",
        lastSeen: "لم يستخدم بعد",
        subscriberName: addForm.subscriberName.trim(),
        phone: addForm.phone.trim(),
        address: addForm.address.trim(),
        note: addForm.note?.trim() || undefined,
      },
      ...prev,
    ])
    toast.success("تم إنشاء المفتاح")
    setAdding(false)
    setAddForm({ ...emptyForm })
  }

  function deleteKey() {
    if (!confirmDelete) return
    setKeys((prev) => prev.filter((k) => k.id !== confirmDelete.id))
    toast.success("تم حذف المفتاح")
    setConfirmDelete(null)
  }

  function resetDevices() {
    if (!confirmReset) return
    setKeys((prev) =>
      prev.map((k) =>
        k.id === confirmReset.id ? { ...k, deviceCount: 0, lastIp: "—" } : k,
      ),
    )
    toast.success("تمت إعادة ضبط الأجهزة")
    setConfirmReset(null)
  }

  // Counts for filter chips
  const counts = {
    all: keys.length,
    active: keys.filter((k) => k.status === "active").length,
    blocked: keys.filter((k) => k.status === "blocked").length,
    expired: keys.filter((k) => k.status === "expired").length,
  }

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title="المفاتيح"
        description="إدارة مفاتيح التفعيل والمشتركين"
        icon={<Key className="size-5 text-primary-foreground" />}
        actions={
          <Button
            onClick={() => setAdding(true)}
            className="doom-gradient text-primary-foreground hover:opacity-90"
          >
            <Plus className="size-4 ml-1" />
            إضافة مفتاح
          </Button>
        }
      />

      {/* Filters */}
      <Card className="border-border/60 bg-card/60">
        <CardContent className="p-3 sm:p-4 flex flex-col gap-3">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="ابحث بالاسم، الكود، الهاتف أو الـIP..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="pr-10 h-10 bg-input/40"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="h-10 sm:w-[200px]">
                <SelectValue placeholder="الحالة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل الحالات ({counts.all})</SelectItem>
                <SelectItem value="active">فعّال ({counts.active})</SelectItem>
                <SelectItem value="blocked">محظور ({counts.blocked})</SelectItem>
                <SelectItem value="expired">منتهي الصلاحية ({counts.expired})</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-wrap gap-2 text-xs">
            <span className="px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
              فعّال: {counts.active}
            </span>
            <span className="px-2.5 py-1 rounded-full bg-destructive/15 text-destructive border border-destructive/30">
              محظور: {counts.blocked}
            </span>
            <span className="px-2.5 py-1 rounded-full bg-zinc-500/15 text-zinc-300 border border-zinc-500/30">
              منتهي الصلاحية: {counts.expired}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Keys list */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4">
          {filtered.map((k) => (
            <KeyCard
              key={k.id}
              apiKey={k}
              onCopy={copy}
              onEdit={openEdit}
              onReset={setConfirmReset}
              onDelete={setConfirmDelete}
            />
          ))}
        </div>
      ) : (
        <Empty className="border border-dashed border-border/60 bg-card/40 rounded-xl">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Key className="size-6" />
            </EmptyMedia>
            <EmptyTitle>لا توجد مفاتيح مطابقة</EmptyTitle>
            <EmptyDescription>جرّب تغيير الفلتر أو البحث، أو أضف مفتاحاً جديداً.</EmptyDescription>
          </EmptyHeader>
        </Empty>
      )}

      {/* ========= EDIT KEY DIALOG ========= */}
      <Dialog
        open={!!editing}
        onOpenChange={(o) => {
          if (!o) {
            setEditing(null)
            setEditForm(null)
          }
        }}
      >
        <DialogContent className="max-w-[calc(100vw-2rem)] sm:max-w-xl max-h-[calc(100dvh-2rem)] overflow-y-auto p-0">
          {/* Header banner */}
          <div className="doom-gradient p-5 sm:p-6">
            <DialogHeader className="text-right">
              <div className="flex items-center gap-3">
                <div className="size-11 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center shrink-0">
                  <Key className="size-5 text-white" />
                </div>
                <div className="min-w-0">
                  <DialogTitle className="text-white text-lg">تعديل المفتاح</DialogTitle>
                  <DialogDescription className="text-white/85 text-xs">
                    عدّل بيانات المشترك والصلاحيات والأجهزة
                  </DialogDescription>
                </div>
              </div>
            </DialogHeader>
          </div>

          {editForm && (
            <div className="p-5 sm:p-6 flex flex-col gap-5">
              {/* Code (readonly) */}
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs text-muted-foreground">كود التفعيل</Label>
                <div className="flex items-center gap-2 rounded-lg border border-border/60 bg-muted/30 px-3 py-2.5">
                  <Key className="size-4 text-muted-foreground shrink-0" />
                  <code className="text-sm font-mono flex-1 truncate" dir="ltr">
                    {editForm.code}
                  </code>
                  <button
                    type="button"
                    onClick={() => copy(editForm.code)}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                    aria-label="نسخ"
                  >
                    <Copy className="size-3.5" />
                  </button>
                </div>
              </div>

              {/* Subscriber section */}
              <div className="flex flex-col gap-3">
                <h4 className="text-xs font-bold text-muted-foreground flex items-center gap-1.5 uppercase tracking-wider">
                  <User className="size-3.5" />
                  بيانات المشترك
                </h4>
                <div className="flex flex-col gap-1.5">
                  <Label className="text-xs">اسم المشترك</Label>
                  <Input
                    value={editForm.subscriberName}
                    onChange={(e) =>
                      setEditForm({ ...editForm, subscriberName: e.target.value })
                    }
                    placeholder="مثال: أحمد العبادي"
                    className="h-10"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1.5">
                    <Label className="text-xs">رقم الهاتف</Label>
                    <Input
                      value={editForm.phone}
                      onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                      placeholder="+9647..."
                      className="h-10 font-mono"
                      dir="ltr"
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label className="text-xs">العنوان</Label>
                    <Input
                      value={editForm.address}
                      onChange={(e) => setEditForm({ ...editForm, address: e.target.value })}
                      placeholder="المدينة - المنطقة"
                      className="h-10"
                    />
                  </div>
                </div>
              </div>

              {/* Subscription section */}
              <div className="flex flex-col gap-3">
                <h4 className="text-xs font-bold text-muted-foreground flex items-center gap-1.5 uppercase tracking-wider">
                  <ShieldAlert className="size-3.5" />
                  بيانات الاشتراك
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1.5">
                    <Label className="text-xs">الحالة</Label>
                    <Select
                      value={editForm.status}
                      onValueChange={(v) =>
                        setEditForm({ ...editForm, status: v as ApiKey["status"] })
                      }
                    >
                      <SelectTrigger className="h-10">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">فعّال</SelectItem>
                        <SelectItem value="blocked">محظور</SelectItem>
                        <SelectItem value="expired">منتهي الصلاحية</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label className="text-xs">الصلاحية</Label>
                    <Select
                      value={editForm.expireDate}
                      onValueChange={(v) => setEditForm({ ...editForm, expireDate: v })}
                    >
                      <SelectTrigger className="h-10">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {expireOptions.map((o) => (
                          <SelectItem key={o} value={o}>
                            {o}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1.5">
                    <Label className="text-xs">الأجهزة المسجلة</Label>
                    <Input
                      type="number"
                      min={0}
                      value={editForm.deviceCount}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          deviceCount: Number(e.target.value) || 0,
                        })
                      }
                      className="h-10"
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label className="text-xs">الحد الأقصى للأجهزة</Label>
                    <Input
                      type="number"
                      min={1}
                      value={editForm.maxDevices}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          maxDevices: Number(e.target.value) || 1,
                        })
                      }
                      className="h-10"
                    />
                  </div>
                </div>
              </div>

              {/* Info readonly section */}
              <div className="rounded-lg border border-border/60 bg-muted/20 p-3 grid grid-cols-2 gap-3 text-xs">
                <div>
                  <p className="text-muted-foreground mb-0.5">آخر IP</p>
                  <p className="font-mono truncate" dir="ltr">
                    {editForm.lastIp}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground mb-0.5">آخر اتصال</p>
                  <p className="truncate">{editForm.lastSeen}</p>
                </div>
              </div>

              {/* Note */}
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs">ملاحظة (اختيارية)</Label>
                <Textarea
                  value={editForm.note ?? ""}
                  onChange={(e) => setEditForm({ ...editForm, note: e.target.value })}
                  placeholder="مثال: عميل مميز / VIP"
                  rows={2}
                  className="resize-none"
                />
              </div>

              {/* Tip */}
              <div className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-200">
                <ShieldAlert className="size-4 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  أي تعديل على الحالة قد يؤثر على المشترك فوراً عند الربط بالسيرفر.
                </p>
              </div>
            </div>
          )}

          <DialogFooter className="px-5 pb-5 sm:px-6 sm:pb-6 flex-row gap-2">
            <Button
              onClick={saveEdit}
              className="doom-gradient text-primary-foreground hover:opacity-90 flex-1 sm:flex-initial"
            >
              <Check className="size-4 ml-1" />
              حفظ التعديلات
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setEditing(null)
                setEditForm(null)
              }}
              className="flex-1 sm:flex-initial"
            >
              إلغاء
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ========= ADD KEY DIALOG ========= */}
      <Dialog
        open={adding}
        onOpenChange={(o) => {
          if (!o) {
            setAdding(false)
            setAddForm({ ...emptyForm })
          }
        }}
      >
        <DialogContent className="max-w-[calc(100vw-2rem)] sm:max-w-xl max-h-[calc(100dvh-2rem)] overflow-y-auto p-0">
          <div className="doom-gradient p-5 sm:p-6">
            <DialogHeader className="text-right">
              <div className="flex items-center gap-3">
                <div className="size-11 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center shrink-0">
                  <Plus className="size-5 text-white" />
                </div>
                <div className="min-w-0">
                  <DialogTitle className="text-white text-lg">إضافة مفتاح جديد</DialogTitle>
                  <DialogDescription className="text-white/85 text-xs">
                    أدخل بيانات المشترك وكود التفعيل
                  </DialogDescription>
                </div>
              </div>
            </DialogHeader>
          </div>

          <div className="p-5 sm:p-6 flex flex-col gap-5">
            {/* Subscriber */}
            <div className="flex flex-col gap-3">
              <h4 className="text-xs font-bold text-muted-foreground flex items-center gap-1.5 uppercase tracking-wider">
                <User className="size-3.5" />
                بيانات المشترك
              </h4>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="add-name" className="text-xs">
                  اسم المشترك <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="add-name"
                  value={addForm.subscriberName}
                  onChange={(e) => setAddForm({ ...addForm, subscriberName: e.target.value })}
                  placeholder="مثال: أحمد العبادي"
                  className="h-10"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="add-phone" className="text-xs">
                    رقم الهاتف
                  </Label>
                  <div className="relative">
                    <Phone className="absolute right-3 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
                    <Input
                      id="add-phone"
                      value={addForm.phone}
                      onChange={(e) => setAddForm({ ...addForm, phone: e.target.value })}
                      placeholder="+9647..."
                      className="h-10 pr-9 font-mono"
                      dir="ltr"
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="add-address" className="text-xs">
                    العنوان
                  </Label>
                  <div className="relative">
                    <MapPin className="absolute right-3 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
                    <Input
                      id="add-address"
                      value={addForm.address}
                      onChange={(e) => setAddForm({ ...addForm, address: e.target.value })}
                      placeholder="المدينة - المنطقة"
                      className="h-10 pr-9"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Subscription */}
            <div className="flex flex-col gap-3">
              <h4 className="text-xs font-bold text-muted-foreground flex items-center gap-1.5 uppercase tracking-wider">
                <Key className="size-3.5" />
                بيانات الاشتراك
              </h4>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="add-code" className="text-xs">
                  كود التفعيل <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="add-code"
                  value={addForm.code}
                  onChange={(e) => setAddForm({ ...addForm, code: e.target.value })}
                  placeholder="DOOM-XXXX-XXXX-XXXX"
                  className="h-10 font-mono"
                  dir="ltr"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <Label className="text-xs">الصلاحية</Label>
                  <Select
                    value={addForm.expireDate}
                    onValueChange={(v) => setAddForm({ ...addForm, expireDate: v })}
                  >
                    <SelectTrigger className="h-10">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {expireOptions.map((o) => (
                        <SelectItem key={o} value={o}>
                          {o}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label className="text-xs">الحد الأقصى للأجهزة</Label>
                  <Input
                    type="number"
                    min={1}
                    value={addForm.maxDevices}
                    onChange={(e) =>
                      setAddForm({
                        ...addForm,
                        maxDevices: Number(e.target.value) || 1,
                      })
                    }
                    className="h-10"
                  />
                </div>
              </div>
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs">ملاحظة (اختيارية)</Label>
                <Textarea
                  value={addForm.note ?? ""}
                  onChange={(e) => setAddForm({ ...addForm, note: e.target.value })}
                  placeholder="مثال: عميل مميز"
                  rows={2}
                  className="resize-none"
                />
              </div>
            </div>
          </div>

          <DialogFooter className="px-5 pb-5 sm:px-6 sm:pb-6 flex-row gap-2">
            <Button
              onClick={addKey}
              className="doom-gradient text-primary-foreground hover:opacity-90 flex-1 sm:flex-initial"
            >
              <Plus className="size-4 ml-1" />
              إنشاء المفتاح
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setAdding(false)
                setAddForm({ ...emptyForm })
              }}
              className="flex-1 sm:flex-initial"
            >
              إلغاء
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!confirmDelete}
        onOpenChange={(o) => !o && setConfirmDelete(null)}
        title="حذف المفتاح"
        description={
          <>
            سيتم حذف مفتاح المشترك <strong>{confirmDelete?.subscriberName}</strong> (
            <span className={cn("font-mono")}>{confirmDelete?.code}</span>) نهائياً. هذا الإجراء غير
            قابل للتراجع.
          </>
        }
        confirmLabel="نعم، حذف"
        destructive
        onConfirm={deleteKey}
      />

      <ConfirmDialog
        open={!!confirmReset}
        onOpenChange={(o) => !o && setConfirmReset(null)}
        title="إعادة ضبط الأجهزة"
        description="سيتم إخراج جميع الأجهزة المسجلة على هذا المفتاح. سيحتاج المشترك لإعادة التفعيل."
        confirmLabel="نعم، متابعة"
        onConfirm={resetDevices}
      />
    </div>
  )
}
