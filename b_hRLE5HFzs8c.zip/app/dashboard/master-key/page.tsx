"use client"

import { useState } from "react"
import { CheckCircle2, Eye, EyeOff, KeyRound, RefreshCw, ShieldAlert } from "lucide-react"
import { toast } from "sonner"
import { PageHeader } from "@/components/dashboard/page-header"
import { ConfirmDialog } from "@/components/dashboard/confirm-dialog"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"

export default function MasterKeyPage() {
  const [revealed, setRevealed] = useState(false)
  const [changing, setChanging] = useState(false)
  const [newKey, setNewKey] = useState("")
  const [confirmNewKey, setConfirmNewKey] = useState("")
  const [confirmChange, setConfirmChange] = useState(false)
  const [lastTest, setLastTest] = useState("ناجح — قبل ساعة")
  const [testing, setTesting] = useState(false)

  const masked = "••••••••1234"

  function runTest() {
    setTesting(true)
    setTimeout(() => {
      setLastTest("ناجح — الآن")
      toast.success("تم اختبار المفتاح الأساسي بنجاح")
      setTesting(false)
    }, 900)
  }

  function startChange() {
    if (!newKey || newKey.length < 6) {
      toast.error("المفتاح الجديد قصير جداً")
      return
    }
    if (newKey !== confirmNewKey) {
      toast.error("المفتاحان غير متطابقين")
      return
    }
    setConfirmChange(true)
  }

  function applyChange() {
    toast.success("تم تغيير المفتاح الأساسي")
    setChanging(false)
    setNewKey("")
    setConfirmNewKey("")
    setConfirmChange(false)
  }

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title="المفتاح الأساسي"
        description="إدارة Master Key الذي يعتمد عليه النظام"
        icon={<KeyRound className="size-5 text-primary-foreground" />}
      />

      <Card className="border-border/60 bg-card/60">
        <CardContent className="p-5 flex flex-col gap-5">
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div>
              <p className="text-xs text-muted-foreground mb-1">الحالة</p>
              <Badge className="bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                <CheckCircle2 className="size-3 ml-1" />
                يعمل بشكل صحيح
              </Badge>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground mb-1">آخر اختبار</p>
              <p className="text-sm">{lastTest}</p>
            </div>
          </div>

          <div className="rounded-xl border border-border/60 bg-muted/20 p-4">
            <p className="text-xs text-muted-foreground mb-2">المفتاح الحالي</p>
            <div className="flex items-center gap-2">
              <code className="font-mono text-lg flex-1 truncate" dir="ltr">
                {revealed ? "MK_DOOM_2026_PROXY_1234" : masked}
              </code>
              <Button
                size="icon"
                variant="ghost"
                onClick={() => setRevealed((v) => !v)}
                aria-label={revealed ? "إخفاء" : "إظهار"}
              >
                {revealed ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </Button>
            </div>
            <p className="text-[11px] text-muted-foreground mt-2">
              لأمانك، لا يُعرض المفتاح كاملاً افتراضياً.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button onClick={runTest} disabled={testing} variant="outline">
              <RefreshCw className={testing ? "size-4 ml-1 animate-spin" : "size-4 ml-1"} />
              اختبار المفتاح
            </Button>
            <Button
              onClick={() => setChanging(true)}
              className="doom-gradient text-primary-foreground hover:opacity-90"
            >
              تغيير المفتاح
            </Button>
          </div>

          <div className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-200">
            <ShieldAlert className="size-4 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              تغيير المفتاح الأساسي قد يوقف الخدمة مؤقتاً إذا كان غير صحيح. تأكد من حفظ نسخة قبل المتابعة.
            </p>
          </div>
        </CardContent>
      </Card>

      <Dialog open={changing} onOpenChange={setChanging}>
        <DialogContent className="max-w-[calc(100vw-2rem)] sm:max-w-md max-h-[calc(100dvh-2rem)] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-right">تغيير المفتاح الأساسي</DialogTitle>
            <DialogDescription className="text-right">
              أدخل المفتاح الجديد مرتين للتأكيد.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="new-mk" className="text-xs">
                المفتاح الجديد
              </Label>
              <Input
                id="new-mk"
                type="password"
                value={newKey}
                onChange={(e) => setNewKey(e.target.value)}
                className="h-10 font-mono"
                dir="ltr"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="confirm-mk" className="text-xs">
                تأكيد المفتاح
              </Label>
              <Input
                id="confirm-mk"
                type="password"
                value={confirmNewKey}
                onChange={(e) => setConfirmNewKey(e.target.value)}
                className="h-10 font-mono"
                dir="ltr"
              />
            </div>
          </div>
          <DialogFooter className="flex-row gap-2">
            <Button
              onClick={startChange}
              className="doom-gradient text-primary-foreground hover:opacity-90 flex-1 sm:flex-initial"
            >
              متابعة
            </Button>
            <Button
              variant="outline"
              onClick={() => setChanging(false)}
              className="flex-1 sm:flex-initial"
            >
              إلغاء
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={confirmChange}
        onOpenChange={setConfirmChange}
        title="تأكيد تغيير المفتاح الأساسي"
        description="بعد التغيير، يجب أن يستخدم النظام المفتاح الجديد. هل أنت متأكد؟"
        confirmLabel="نعم، تغيير"
        destructive
        onConfirm={applyChange}
      />
    </div>
  )
}
