"use client"

import { useState } from "react"
import { Bell, Lock, Save, Server, Settings as SettingsIcon, ShieldAlert } from "lucide-react"
import { toast } from "sonner"
import { PageHeader } from "@/components/dashboard/page-header"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

interface SettingsSectionProps {
  icon: React.ElementType
  title: string
  description: string
  children: React.ReactNode
}

function SettingsSection({
  icon: Icon,
  title,
  description,
  children,
}: SettingsSectionProps) {
  return (
    <Card className="border-border/60 bg-card/60">
      <CardContent className="p-5">
        <div className="flex items-start gap-3 mb-5 pb-4 border-b border-border/40">
          <div className="size-10 rounded-xl doom-gradient flex items-center justify-center shrink-0">
            <Icon className="size-5 text-primary-foreground" />
          </div>
          <div className="min-w-0">
            <h3 className="font-bold">{title}</h3>
            <p className="text-xs text-muted-foreground mt-0.5">{description}</p>
          </div>
        </div>
        {children}
      </CardContent>
    </Card>
  )
}

export default function SettingsPage() {
  const [logLevel, setLogLevel] = useState("info")
  const [goldLock, setGoldLock] = useState(true)
  const [notifyErrors, setNotifyErrors] = useState(true)
  const [notifyLogins, setNotifyLogins] = useState(false)
  const [autoBackup, setAutoBackup] = useState(true)

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title="الإعدادات"
        description="إعدادات السيرفر العامة والأمان"
        icon={<SettingsIcon className="size-5 text-primary-foreground" />}
      />

      {/* Server settings */}
      <SettingsSection
        icon={Server}
        title="إعدادات السيرفر"
        description="بيانات اتصال السيرفر ومستوى السجلات"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs">عنوان السيرفر</Label>
            <Input value="13.50.223.154" readOnly className="font-mono" dir="ltr" />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs">المنفذ</Label>
            <Input value="8888" readOnly className="font-mono" dir="ltr" />
          </div>
          <div className="flex flex-col gap-1.5 sm:col-span-2">
            <Label className="text-xs">مستوى السجلات</Label>
            <Select value={logLevel} onValueChange={setLogLevel}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="debug">Debug — أكبر قدر من التفاصيل</SelectItem>
                <SelectItem value="info">Info — افتراضي</SelectItem>
                <SelectItem value="warn">Warning — التحذيرات فقط</SelectItem>
                <SelectItem value="error">Error — الأخطاء فقط</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </SettingsSection>

      {/* Security */}
      <SettingsSection
        icon={Lock}
        title="الأمان"
        description="كلمة مرور المسؤول وقفل Gold State"
      >
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs">كلمة مرور المسؤول</Label>
              <Input type="password" placeholder="••••••••" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs">تأكيد كلمة المرور</Label>
              <Input type="password" placeholder="••••••••" />
            </div>
          </div>
          <div className="flex items-center justify-between gap-3 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3">
            <div className="flex items-start gap-2 min-w-0">
              <ShieldAlert className="size-4 text-amber-300 shrink-0 mt-0.5" />
              <div className="min-w-0">
                <p className="font-medium text-sm">قفل Gold State</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  يمنع تنفيذ الإجراءات الخطيرة بدون تأكيد إضافي.
                </p>
              </div>
            </div>
            <Switch checked={goldLock} onCheckedChange={setGoldLock} />
          </div>
        </div>
      </SettingsSection>

      {/* Notifications */}
      <SettingsSection
        icon={Bell}
        title="الإشعارات"
        description="تحكّم بالأحداث التي تستدعي تنبيه"
      >
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between gap-3 rounded-lg border border-border/60 bg-muted/20 p-3">
            <div className="min-w-0">
              <p className="font-medium text-sm">إشعار عند الأخطاء</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                إرسال تنبيه فوري عند حدوث خطأ في السيرفر.
              </p>
            </div>
            <Switch checked={notifyErrors} onCheckedChange={setNotifyErrors} />
          </div>
          <div className="flex items-center justify-between gap-3 rounded-lg border border-border/60 bg-muted/20 p-3">
            <div className="min-w-0">
              <p className="font-medium text-sm">إشعار عند تسجيل دخول جديد</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                تنبيه عند ربط جهاز جديد بأي مفتاح.
              </p>
            </div>
            <Switch checked={notifyLogins} onCheckedChange={setNotifyLogins} />
          </div>
          <div className="flex items-center justify-between gap-3 rounded-lg border border-border/60 bg-muted/20 p-3">
            <div className="min-w-0">
              <p className="font-medium text-sm">نسخ احتياطي تلقائي يومي</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                إنشاء نسخة احتياطية تلقائية كل يوم في الـ 03:00 صباحاً.
              </p>
            </div>
            <Switch checked={autoBackup} onCheckedChange={setAutoBackup} />
          </div>
        </div>
      </SettingsSection>

      <Button
        onClick={() => toast.success("تم حفظ الإعدادات")}
        className="doom-gradient text-primary-foreground hover:opacity-90 self-start"
      >
        <Save className="size-4 ml-1" />
        حفظ الإعدادات
      </Button>
    </div>
  )
}
