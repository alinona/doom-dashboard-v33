// Mock authentication — frontend-only.
// Replace with real backend auth when wiring up the server.

const AUTH_KEY = "doom_admin_session"

export interface AdminSession {
  username: string
  loggedInAt: string
}

export function getSession(): AdminSession | null {
  if (typeof window === "undefined") return null
  try {
    const raw = window.localStorage.getItem(AUTH_KEY)
    if (!raw) return null
    return JSON.parse(raw) as AdminSession
  } catch {
    return null
  }
}

export function setSession(username: string) {
  if (typeof window === "undefined") return
  const session: AdminSession = {
    username,
    loggedInAt: new Date().toISOString(),
  }
  window.localStorage.setItem(AUTH_KEY, JSON.stringify(session))
}

export function clearSession() {
  if (typeof window === "undefined") return
  window.localStorage.removeItem(AUTH_KEY)
}

// Mock credentials — purely client-side, will be replaced by real auth.
export function mockLogin(username: string, password: string): boolean {
  return username.trim() === "admin" && password === "admin"
}
